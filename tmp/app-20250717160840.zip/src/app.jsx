import React, { useEffect, useState } from "react";
import ReactDOM from "react-dom";

const BACKEND_BASE_URL = "https://intlxassetmgr-proxy.onrender.com";

function App() {
  const [assets, setAssets] = useState([]);
  const [requester, setRequester] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedAsset, setSelectedAsset] = useState(null);
  const [editData, setEditData] = useState({});

  useEffect(() => {
    const ZAFClient = window.ZAFClient;
    const client = ZAFClient.init();

    async function load() {
      const ticketData = await client.get("ticket.requester");
      setRequester(ticketData["ticket.requester"]);
      const userId = ticketData["ticket.requester"]?.id;
      if (userId) {
        fetch(`${BACKEND_BASE_URL}/api/user-assets?user_id=${userId}`)
          .then((res) => res.json())
          .then((data) => setAssets(data.assets || []))
          .finally(() => setLoading(false));
      }
    }
    load();
  }, []);

  function openAssetDetails(asset) {
    setSelectedAsset(asset);
    setEditData(asset.custom_object_fields || {});
  }

  function handleChange(e) {
    const { name, value } = e.target;
    setEditData((prev) => ({ ...prev, [name]: value }));
  }

  async function saveChanges() {
    if (!selectedAsset) return;
    const res = await fetch(`${BACKEND_BASE_URL}/api/assets/${selectedAsset.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(editData),
    });
    if (res.ok) {
      const updatedAsset = await res.json();
      setAssets((prev) =>
        prev.map((a) => (a.id === updatedAsset.id ? updatedAsset : a))
      );
      setSelectedAsset(null);
      setEditData({});
    } else {
      alert("Failed to save changes.");
    }
  }

  function cancelEdit() {
    setSelectedAsset(null);
    setEditData({});
  }

  if (loading) return <p>Loading assets...</p>;

  return (
    <div style={{ fontFamily: "sans-serif", padding: 8 }}>
      <h2>Asset Manager</h2>
      <div>
        <b>Requester:</b> {requester ? requester.name : "Unknown"}
      </div>

      {!selectedAsset && (
        <ul>
          {assets.map((asset) => (
            <li
              key={asset.id}
              style={{ cursor: "pointer", marginBottom: 6 }}
              onClick={() => openAssetDetails(asset)}
            >
              <b>{asset.custom_object_fields?.asset_name}</b>{" "}
              {asset.custom_object_fields?.serial_number &&
                `— Serial: ${asset.custom_object_fields.serial_number}`}
            </li>
          ))}
        </ul>
      )}

      {selectedAsset && (
        <div>
          <h3>Edit Asset: {selectedAsset.custom_object_fields?.asset_name}</h3>
          <label>
            Asset Name:
            <input
              name="asset_name"
              value={editData.asset_name || ""}
              onChange={handleChange}
            />
          </label>
          <br />
          <label>
            Serial Number:
            <input
              name="serial_number"
              value={editData.serial_number || ""}
              onChange={handleChange}
            />
          </label>
          <br />
          <label>
            Status:
            <input
              name="status"
              value={editData.status || ""}
              onChange={handleChange}
            />
          </label>
          <br />
          {/* Add other editable fields here as needed */}
          <button onClick={saveChanges}>Save</button>
          <button onClick={cancelEdit} style={{ marginLeft: 8 }}>
            Cancel
          </button>
        </div>
      )}
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById("root"));
